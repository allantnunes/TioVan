package br.com.bandtec.agendadeobjetivos.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Mentor {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String nome;

	private String profissao;
	
	
	public Mentor(String nome, String profissao) {
			this.nome = nome;
			this.profissao =  profissao;
		
	}

	public Long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}
	
	

}
