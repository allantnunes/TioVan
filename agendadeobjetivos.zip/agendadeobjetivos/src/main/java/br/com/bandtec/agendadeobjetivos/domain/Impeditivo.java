package br.com.bandtec.agendadeobjetivos.domain;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;

@Entity
@Table(name="impeditivo")
public class Impeditivo {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String nome;
	
	private String motivo;
	
	@ManyToOne
	@JoinColumn(name = "objetivo_id")
	private Objetivo objetivo;
	
	public Impeditivo() {}

	public Impeditivo(String nome, String motivo) {
		super();
		this.nome = nome;
		this.motivo = motivo;
	}

	void setObjetivo(Objetivo objetivo) {
		this.objetivo = objetivo;
	}
}
