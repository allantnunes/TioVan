package br.com.bandtec.agendadeobjetivos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendadeobjetivosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendadeobjetivosApplication.class, args);
	}

}
